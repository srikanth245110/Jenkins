#Java-maven-Git-Tomcat-Jenkins Configuration on RedHat

#Launch an EC2 instance RedHat with t2.micro type and connect to it. If you are first time using EC2 instances, refer the word document "AWS-Connect-To-EC2-Instance" in Phase-1

#login to root
echo login to root
sudo -i

#install wget
echo install 'wget' to download the files from internet.
yum install wget -y

#==========GIT INSTALLATION START==========#

#Git Setup:
echo Git Setup:
#Git Installation
echo Git Installation
yum install git -y

#GitHome: /usr/bin/git  ( find  /  -name "git" -- to search with command)
echo GitHome: /usr/bin/git  ( find  /  -name "git" -- to search with command)

#Git Version
echo Git Version
git --version

#==========GIT INSTALLATION END==========#

#==========JAVA INSTALLATION START==========#

#JAVA Setup
echo JAVA Setup

sudo yum install -y java-1.8.0-openjdk-devel # you can choose any methond to install JAVA but make sure you setup the JDK path, other wise builds will be failed with compilation errors.

find / -name "tools*" # find the JDK path where the <JDKpath>/libs/tools.jar is available, copy the <JDKpath>

echo' Maual step
export JAVA_HOME=<JDKpath>
# ex: export JAVA_HOME=/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.292.b10-1.el8_4.x86_64/
'
export PATH=$JAVA_HOME/bin:$PATH

java -version

#Java Home path: /usr/java/jdk1.8.0_131
echo Java Home path: $JAVA_HOME

#===========================JAVA INSTALLATION END=========================================

#===========================MAVEN SETUP START========================================================

#Maven Setup:
echo Maven Setup:

export MAVEN_VERSION=3.8.1
#Download maven:
echo Download maven:
wget http://mirror.cogentco.com/pub/apache/maven/maven-3/${MAVEN_VERSION}/binaries/apache-maven-${MAVEN_VERSION}-bin.tar.gz

#Unzip tar file
echo Unzip tar file
tar zxpvf apache-maven-${MAVEN_VERSION}-bin.tar.gz

mkdir /usr/lib/maven

mv apache-maven-${MAVEN_VERSION} /usr/lib/maven/apache-maven-${MAVEN_VERSION}

echo maven home: /usr/lib/maven/apache-maven-${MAVEN_VERSION}

#Setup Maven
export MAVEN_HOME=/usr/lib/maven/apache-maven-${MAVEN_VERSION}

export M3=$MAVEN_HOME/bin

export PATH=$M3:$PATH

#check maven: mvn -v
echo check maven: mvn -v
mvn -v

#vi /root/apache-maven-3.5.4/conf/settings.xml: update this settings file with below nexus credentials.
echo'
	<server>
		<id>deployment</id>
		<username>deployment</username>
		<password>deployment123</password>
	</server>
'

#============MAVEN SETUP END============#

#============JENKINS SETUP START============#
#Refer: https://www.jenkins.io/doc/book/installing/linux/#red-hat-centos

sudo wget -O /etc/yum.repos.d/jenkins.repo https://pkg.jenkins.io/redhat/jenkins.repo

sudo rpm --import https://pkg.jenkins.io/redhat/jenkins.io.key

sudo yum upgrade -y

sudo yum install jenkins -y

sudo systemctl daemon-reload

sudo systemctl start jenkins

#sudo systemctl status jenkins
#sudo systemctl stop jenkins

#Startup the jenkins server and then launch the URL in any browser: http://<PublicIP>:8080

#Refer the word document "Install-Setup-Jenkins" in Phase-1 to further Jenkins setup


#============JENKINS SETUP END============#




