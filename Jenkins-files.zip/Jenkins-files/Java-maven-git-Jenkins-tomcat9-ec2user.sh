#Java-maven-Git-Tomcat-Jenkins Configuration on RedHat

#Launch an EC2 instance RedHat with t2.micro type and connect to it. If you are first time using EC2 instances, refer the word document "AWS-Connect-To-EC2-Instance" in Phase-1

#install wget
echo install 'wget' to download the files from internet.
sudo yum install wget -y

#==========GIT INSTALLATION START==========#

#Git Setup:
echo Git Setup:
#Git Installation
echo Git Installation
sudo yum install git -y

#GitHome: /usr/bin/git  ( find  /  -name "git" -- to search with command)
echo GitHome: /usr/bin/git  ( find  /  -name "git" -- to search with command)

#Git Version
echo Git Version
git --version

#==========GIT INSTALLATION END==========#

#==========JAVA INSTALLATION START==========#

#JAVA Setup
echo JAVA Setup

sudo yum install -y java-1.8.0-openjdk-devel # you can choose any methond to install JAVA but make sure you setup the JDK path, other wise builds will be failed with compilation errors.

sudo find / -name "tools*" # find the JDK path where the <JDKpath>/libs/tools.jar is available, copy the <JDKpath>

echo' Maual step
export JAVA_HOME=<JDKpath>
# ex: export JAVA_HOME=/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.292.b10-1.el8_4.x86_64/
'
export PATH=$JAVA_HOME/bin:$PATH

java -version

#Java Home path: /usr/java/jdk1.8.0_131
echo Java Home path: $JAVA_HOME

#===========================JAVA INSTALLATION END=========================================

#===========================MAVEN SETUP START========================================================

#Maven Setup:
echo Maven Setup:

export MAVEN_VERSION=3.8.1
#Download maven:
echo Download maven:
wget http://mirror.cogentco.com/pub/apache/maven/maven-3/${MAVEN_VERSION}/binaries/apache-maven-${MAVEN_VERSION}-bin.tar.gz

#Unzip tar file
echo Unzip tar file
tar zxpvf apache-maven-${MAVEN_VERSION}-bin.tar.gz

sudo mkdir /usr/lib/maven

sudo mv apache-maven-${MAVEN_VERSION} /usr/lib/maven/apache-maven-${MAVEN_VERSION}

echo maven home: /usr/lib/maven/apache-maven-${MAVEN_VERSION}

#Setup Maven
export MAVEN_HOME=/usr/lib/maven/apache-maven-${MAVEN_VERSION}

export M3=$MAVEN_HOME/bin

export PATH=$M3:$PATH

#check maven: mvn -v
echo check maven: mvn -v
mvn -v

#vi /root/apache-maven-3.5.4/conf/settings.xml: update this settings file with below nexus credentials.
echo'
	<server>
		<id>deployment</id>
		<username>deployment</username>
		<password>deployment123</password>
	</server>
'

#============MAVEN SETUP END============#

#============JENKINS SETUP START============#
#Refer: https://www.jenkins.io/doc/book/installing/linux/#red-hat-centos

sudo wget -O /etc/yum.repos.d/jenkins.repo https://pkg.jenkins.io/redhat/jenkins.repo

sudo rpm --import https://pkg.jenkins.io/redhat/jenkins.io.key

#sudo yum upgrade -y

sudo yum install jenkins -y

sudo systemctl daemon-reload

sudo systemctl start jenkins

#sudo systemctl status jenkins
#sudo systemctl stop jenkins
#sudo yum remove jenkins -y #uninstall jenkins
#Startup the jenkins server and then launch the URL in any browser: http://<PublicIP>:8080

#Refer the word document "Install-Setup-Jenkins" in Phase-1 to further Jenkins setup


#============JENKINS SETUP END============#


#===========================TOMCAT SETUP START========================================================

#Tomcat Setup:
echo Tomcat Setup:
export TOMCAT_VERSION=9.0.46
# Everytime you setup this tomcat, verify this URL to get the latest version - http://ftp.cixug.es/apache/tomcat/tomcat-9/

#Download Tomcat
echo Download Tomcat
sudo wget http://ftp.cixug.es/apache/tomcat/tomcat-9/v${TOMCAT_VERSION}/bin/apache-tomcat-${TOMCAT_VERSION}.tar.gz

#Unzip tar file
echo Unzip tar file
tar zxpvf apache-tomcat-${TOMCAT_VERSION}.tar.gz

#Move to folder
echo Move to folder
mv apache-tomcat-${TOMCAT_VERSION} tomcat9

#Update tomcat-users.xml file: sudo vi tomcat9/conf/tomcat-users.xml
echo'
<role rolename="manager-gui"/>
<user username="tomcat" password="s3cret" roles="manager-gui"/>
'

#Check whether its updated properly or not: cat tomcat9/conf/tomcat-users.xml


#Update context.xml to allow to access tomcat from any IP address: sudo vi tomcat9/webapps/manager/META-INF/context.xml

echo'
From: <Valve className="org.apache.catalina.valves.RemoteAddrValve"
         allow="127\.\d+\.\d+\.\d+|::1|0:0:0:0:0:0:0:1" />
To    <Valve className="org.apache.catalina.valves.RemoteAddrValve"
         allow="\d+\.\d+\.\d+\.\d+" />
'
#Check whether its updated properly or not: cat tomcat9/webapps/manager/META-INF/context.xml

#Update the port number in server.xml file: vi tomcat9/conf/server.xml
#The default port number for Jenkins and Tomcat are same
#Two services can't run at same port number.
#Update the line 
echo'
from     <Connector port="8080" protocol="HTTP/1.1"
to       <Connector port="8085" protocol="HTTP/1.1"
'
#Check whether its updated properly or not: cat tomcat9/conf/server.xml

#Startup the server: ./tomcat9/bin/startup.sh
#Shutdown the server: ./tomcat9/bin/shutdown.sh

#Startup the tomcat server and then launch the URL in any browser: http://<PublicIP>:8085

#===========================TOMCAT SETUP END=================================================



